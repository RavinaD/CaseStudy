package com.techM.shareChachaBeans;

public class UserStock {
	private String companyID;
	private String companyName; 
	private int noOfOwnedShares;
	private Double currentPrice;

	public String getCompanyID() {
		return companyID;
	}

	public int getNoOfOwnedShares() {
		return noOfOwnedShares;
	}

	public Double getCurrentPrice() {
		return currentPrice;
	}

	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public void setNoOfOwnedShares(int noOfOwnedShares) {
		this.noOfOwnedShares = noOfOwnedShares;
	}

	public void setCurrentPrice(Double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

}
