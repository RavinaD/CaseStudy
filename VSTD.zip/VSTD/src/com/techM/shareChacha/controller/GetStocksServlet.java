package com.techM.shareChacha.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaDB.UserDB;

/**
 * Servlet implementation class GetStocksServlet
 */
public class GetStocksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetStocksServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
				
		UserDB uDB = new UserDB();
		
		ArrayList<Company> alist = new ArrayList<Company>();
		alist = uDB.getStocks();
		
		/*for( Company cc : alist )
		out.print(cc.getCompanyID());*/
		
		HttpSession session = request.getSession(false);
		if( alist != null ) {
			session.setAttribute("stockList", alist);
			
			RequestDispatcher rd = request.getRequestDispatcher("/updateStocks.jsp");
			rd.forward(request, response);
		}
		else if( alist == null ) {
			session.setAttribute("status", "Error while fetching the data. Please try again..");
			
			RequestDispatcher rd = request.getRequestDispatcher("/admin.jsp");
			rd.forward(request, response);
		}
		
	}



	}


